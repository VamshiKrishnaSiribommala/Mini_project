# Camera-Ready Copy (CRC) LaTeX Source Package: ICDECT-2026
**Paper ID:** 704
**Paper Title:** LungXpert: A Knowledge-Graph-Enhanced Multimodal Framework for Explainable Thoracic Abnormality Analysis from Chest X-Rays and Radiology Reports
**Conference:** 8th International Conference on Data Engineering and Communication Technology (ICDECT-2026)
**Publication Venue:** Springer Lecture Notes in Networks and Systems (LNNS)

## Package Contents
- `main.tex`: Primary LaTeX manuscript formatted in Springer LNNS svproc document class (Strictly 11 pages).
- `references.bib`: Complete BibTeX bibliography with verified DOIs and clean author metadata.
- `svproc.cls`: Official Springer proceedings document class file.
- `llncs.cls`: Companion Springer LNCS document class file.
- `splncs04.bst`: Official Springer BibTeX bibliography style file.
- `figures/`: High-resolution figures and vector PDFs:
  - `architecture_pipeline.png` & `.pdf`: Overall system architecture schematic.
  - `demo_explainability.png`: Twin square UI card for diagnostic input & Grad-CAM.
  - `demo_retrieval.png`: Twin square UI card for case retrieval gallery.
  - `roc_pr_curves.png` & `.pdf`: Macro ROC and Precision-Recall operating trajectories.
  - `retrieval_benchmarks.png` & `.pdf`: Precision@K and ranking fidelity benchmarks.

## Compilation Instructions
Compile with pdfLaTeX:
```bash
pdflatex main.tex
bibtex main
pdflatex main.tex
pdflatex main.tex
```
Output: `main.pdf` (Strictly 11 pages).
